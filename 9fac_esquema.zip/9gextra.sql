-- phpMyAdmin SQL Dump
-- version 2.11.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 11, 2009 at 08:16 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.4-2ubuntu5.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `9gextra`
--

-- --------------------------------------------------------

--
-- Table structure for table `ges_albaranes_traspaso`
--

CREATE TABLE IF NOT EXISTS `ges_albaranes_traspaso` (
  `IdAlbaranTraspaso` smallint(5) unsigned NOT NULL auto_increment,
  `IdAlmacenSalida` smallint(5) unsigned NOT NULL default '0',
  `IdAlmacenRecepcion` smallint(5) unsigned NOT NULL default '0',
  `FechaPedido` date NOT NULL default '0000-00-00',
  `FechaSalida` date NOT NULL default '0000-00-00',
  `Observaciones` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdAlbaranTraspaso`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_albarans`
--

CREATE TABLE IF NOT EXISTS `ges_albarans` (
  `IdAlbaran` int(10) unsigned NOT NULL auto_increment,
  `IdLocal` smallint(6) NOT NULL default '0',
  `IdUsuario` smallint(6) NOT NULL default '0',
  `SerieAlbaran` tinytext NOT NULL,
  `NAlbaran` int(10) unsigned NOT NULL default '0',
  `FechaAlbaran` date NOT NULL default '0000-00-00',
  `IdCliente` tinyint(4) NOT NULL default '0',
  `ImporteNeto` double NOT NULL default '0',
  `IvaImporte` double NOT NULL default '0',
  `TotalImporte` double NOT NULL default '0',
  `ImportePendiente` double NOT NULL default '0',
  `Status` tinyint(1) unsigned NOT NULL default '0',
  `ObraRealizada` tinytext NOT NULL,
  `SerieNumeroAlbaran` tinytext NOT NULL,
  `NombreComercial` tinytext NOT NULL,
  `Direccion` tinytext NOT NULL,
  `Poblacion` tinytext NOT NULL,
  `CIF` tinytext NOT NULL,
  `CodigoPostal` tinytext NOT NULL,
  `Observaciones` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdAlbaran`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_albarans_det`
--

CREATE TABLE IF NOT EXISTS `ges_albarans_det` (
  `IdAlbaranDet` int(10) unsigned NOT NULL auto_increment,
  `IdAlbaran` int(10) unsigned NOT NULL default '0',
  `IdProducto` smallint(5) unsigned NOT NULL default '0',
  `Referencia` tinytext NOT NULL,
  `CodigoBarras` tinytext NOT NULL,
  `Concepto` tinytext NOT NULL,
  `Talla` tinytext NOT NULL,
  `Color` tinytext NOT NULL,
  `Cantidad` int(10) unsigned NOT NULL default '0',
  `Precio` double NOT NULL default '0',
  `Descuento` double NOT NULL default '0',
  `Importe` double NOT NULL default '0',
  `Iva` double NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdAlbaranDet`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_albtraspaso_det`
--

CREATE TABLE IF NOT EXISTS `ges_albtraspaso_det` (
  `IdDetalle` smallint(5) unsigned NOT NULL auto_increment,
  `IdAlbaranTraspaso` smallint(5) unsigned NOT NULL default '0',
  `IdProducto` smallint(5) unsigned NOT NULL default '0',
  `Unidades` smallint(6) NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdDetalle`),
  KEY `IdAlbaran` (`IdAlbaranTraspaso`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_alb_det`
--

CREATE TABLE IF NOT EXISTS `ges_alb_det` (
  `IdDetalle` smallint(5) unsigned NOT NULL default '0',
  `IdAlbaran` smallint(5) unsigned NOT NULL default '0',
  `IdProducto` smallint(5) unsigned NOT NULL default '0',
  `Unidades` smallint(6) NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdDetalle`),
  KEY `IdAlbaran` (`IdAlbaran`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ges_almacenes`
--

CREATE TABLE IF NOT EXISTS `ges_almacenes` (
  `Id` smallint(5) unsigned NOT NULL auto_increment,
  `IdLocal` smallint(5) unsigned NOT NULL default '0',
  `IdProducto` smallint(5) unsigned NOT NULL default '0',
  `Unidades` smallint(6) NOT NULL default '0',
  `StockMin` smallint(5) unsigned NOT NULL default '0',
  `StockMinOnline` smallint(5) unsigned NOT NULL default '0',
  `PrecioVenta` double unsigned NOT NULL default '0',
  `Descuento` double NOT NULL default '0',
  `PrecioVentaOnline` double unsigned NOT NULL default '0',
  `DescuentoOnline` double NOT NULL default '0',
  `TipoImpuesto` tinytext NOT NULL,
  `Impuesto` double unsigned NOT NULL default '0',
  `StockIlimitado` tinyint(1) unsigned NOT NULL default '0',
  `Disponible` tinyint(1) unsigned NOT NULL default '0',
  `DisponibleOnline` tinyint(1) unsigned NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  `Oferta` tinyint(1) unsigned NOT NULL default '0',
  `OfertaOnline` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`Id`),
  UNIQUE KEY `IdLocal` (`IdLocal`,`IdProducto`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_arqueo_caja`
--

CREATE TABLE IF NOT EXISTS `ges_arqueo_caja` (
  `IdArqueo` int(11) NOT NULL default '0',
  `IdLocal` smallint(6) NOT NULL default '0',
  `FechaApertura` datetime NOT NULL default '0000-00-00 00:00:00',
  `FechaCierre` datetime NOT NULL default '0000-00-00 00:00:00',
  `ImporteApertura` double NOT NULL default '0',
  `ImporteIngresos` double NOT NULL default '0',
  `ImporteGastos` double NOT NULL default '0',
  `ImporteAportaciones` double NOT NULL default '0',
  `ImporteSustracciones` double NOT NULL default '0',
  `ImporteTeoricoCierre` double NOT NULL default '0',
  `ImporteCierre` double NOT NULL default '0',
  `ImporteDescuadre` double NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdArqueo`),
  KEY `FechaArqueo` (`FechaApertura`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ges_bugs`
--

CREATE TABLE IF NOT EXISTS `ges_bugs` (
  `IdBug` bigint(20) NOT NULL auto_increment,
  `LOC` tinytext NOT NULL,
  `Urgencia` tinyint(4) NOT NULL default '0',
  `Categoria` tinytext NOT NULL,
  `Titulo` tinytext NOT NULL,
  `QueDonde` text NOT NULL,
  `QueEsperaba` text NOT NULL,
  `QueOcurrio` text NOT NULL,
  `LogHistorico` text NOT NULL,
  `Status` tinyint(4) NOT NULL default '0',
  `Eliminado` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`IdBug`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_clientes`
--

CREATE TABLE IF NOT EXISTS `ges_clientes` (
  `IdCliente` smallint(5) unsigned NOT NULL auto_increment,
  `TipoCliente` enum('Particular','Empresa') NOT NULL default 'Particular',
  `NombreComercial` tinytext NOT NULL,
  `NombreLegal` tinytext NOT NULL,
  `NumeroFiscal` tinytext NOT NULL,
  `Direccion` tinytext NOT NULL,
  `CP` tinytext NOT NULL,
  `Localidad` tinytext NOT NULL,
  `IdPais` smallint(5) unsigned NOT NULL default '0',
  `Descuento` double unsigned NOT NULL default '0',
  `CuentaBancaria` tinytext NOT NULL,
  `IdModPagoHabitual` smallint(5) unsigned NOT NULL default '0',
  `Telefono1` tinytext NOT NULL,
  `Telefono2` tinytext NOT NULL,
  `Email` tinytext NOT NULL,
  `PaginaWeb` tinytext NOT NULL,
  `Contacto` tinytext NOT NULL,
  `Cargo` tinytext NOT NULL,
  `Comentarios` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdCliente`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_colores`
--

CREATE TABLE IF NOT EXISTS `ges_colores` (
  `Id` smallint(5) unsigned NOT NULL auto_increment,
  `IdColor` smallint(5) unsigned NOT NULL default '0',
  `IdIdioma` smallint(5) unsigned NOT NULL default '0',
  `Color` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`Id`),
  KEY `IdColor` (`IdColor`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_compras`
--

CREATE TABLE IF NOT EXISTS `ges_compras` (
  `IdCompra` smallint(5) unsigned NOT NULL auto_increment,
  `IdPedido` smallint(5) unsigned NOT NULL default '0',
  `IdProducto` smallint(5) unsigned NOT NULL default '0',
  `Unidades` smallint(6) NOT NULL default '0',
  `PrecioUnidad` double NOT NULL default '0',
  `Descuento` double NOT NULL default '0',
  `Impuesto` double NOT NULL default '0',
  `UdsStock` smallint(6) NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdCompra`),
  KEY `IdAlbaran` (`IdPedido`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_dinero_movimientos`
--

CREATE TABLE IF NOT EXISTS `ges_dinero_movimientos` (
  `IdOperacionCaja` int(11) NOT NULL auto_increment,
  `IdArqueoCaja` int(11) NOT NULL default '0',
  `IdLocal` smallint(6) NOT NULL default '0',
  `TipoOperacion` enum('Ingreso','Gasto','Aportacion','Sustraccion') NOT NULL default 'Ingreso',
  `FechaCaja` date NOT NULL default '0000-00-00',
  `Concepto` tinytext NOT NULL,
  `IdFactura` int(11) NOT NULL default '0',
  `IdAlbaran` smallint(6) NOT NULL default '0',
  `Importe` double NOT NULL default '0',
  `IdModalidadPago` tinyint(4) NOT NULL default '0',
  `CuentaBancaria` tinytext NOT NULL,
  `FechaInsercion` datetime NOT NULL default '0000-00-00 00:00:00',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdOperacionCaja`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_facturas`
--

CREATE TABLE IF NOT EXISTS `ges_facturas` (
  `IdFactura` int(10) unsigned NOT NULL auto_increment,
  `IdLocal` smallint(6) NOT NULL default '0',
  `IdUsuario` smallint(6) NOT NULL default '0',
  `SerieFactura` tinytext NOT NULL,
  `NFactura` int(10) unsigned NOT NULL default '0',
  `FechaFactura` date NOT NULL default '0000-00-00',
  `IdCliente` tinyint(4) NOT NULL default '0',
  `ImporteNeto` double NOT NULL default '0',
  `IvaImporte` double NOT NULL default '0',
  `TotalImporte` double NOT NULL default '0',
  `ImportePendiente` double NOT NULL default '0',
  `Status` tinyint(1) unsigned NOT NULL default '0',
  `ObraRealizada` tinytext NOT NULL,
  `SerieNumeroFactura` tinytext NOT NULL,
  `NombreComercial` tinytext NOT NULL,
  `Direccion` tinytext NOT NULL,
  `Poblacion` tinytext NOT NULL,
  `CIF` tinytext NOT NULL,
  `CodigoPostal` tinytext NOT NULL,
  `Observaciones` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdFactura`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_facturas_det`
--

CREATE TABLE IF NOT EXISTS `ges_facturas_det` (
  `IdFacturaDet` int(10) unsigned NOT NULL auto_increment,
  `IdFactura` int(10) unsigned NOT NULL default '0',
  `IdProducto` smallint(5) unsigned NOT NULL default '0',
  `Referencia` tinytext NOT NULL,
  `CodigoBarras` tinytext NOT NULL,
  `Concepto` tinytext NOT NULL,
  `Talla` tinytext NOT NULL,
  `Color` tinytext NOT NULL,
  `Cantidad` int(10) unsigned NOT NULL default '0',
  `Precio` double NOT NULL default '0',
  `Descuento` double NOT NULL default '0',
  `Importe` double NOT NULL default '0',
  `Iva` double NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdFacturaDet`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=56 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_factura_formatos`
--

CREATE TABLE IF NOT EXISTS `ges_factura_formatos` (
  `IdFormato` smallint(5) unsigned NOT NULL auto_increment,
  `Formato` tinytext NOT NULL,
  `Dato1` enum('Y','N','S','') NOT NULL default '',
  `Simbolo1` enum('\\','-','/','') NOT NULL default '',
  `Dato2` enum('Y','N','S','') NOT NULL default '',
  `Simbolo2` enum('\\','-','/','') NOT NULL default '',
  `Dato3` enum('Y','N','S','') NOT NULL default '',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdFormato`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_familias`
--

CREATE TABLE IF NOT EXISTS `ges_familias` (
  `Id` smallint(5) unsigned NOT NULL auto_increment,
  `IdFamilia` smallint(5) unsigned NOT NULL default '0',
  `IdIdioma` smallint(5) unsigned NOT NULL default '0',
  `Familia` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`Id`),
  KEY `IdFamilia` (`IdFamilia`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=85 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_idiomas`
--

CREATE TABLE IF NOT EXISTS `ges_idiomas` (
  `IdIdioma` smallint(5) unsigned NOT NULL auto_increment,
  `Idioma` tinytext NOT NULL,
  `iso` tinytext NOT NULL,
  `Traducido` tinyint(1) unsigned NOT NULL default '0',
  `Datos` tinyint(1) unsigned NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdIdioma`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_inventario_ajustes`
--

CREATE TABLE IF NOT EXISTS `ges_inventario_ajustes` (
  `IdAjusteInventario` int(10) unsigned NOT NULL auto_increment,
  `TipoAjuste` tinytext NOT NULL,
  `IdProducto` smallint(5) unsigned NOT NULL default '0',
  `IdLocal` tinyint(4) NOT NULL default '0',
  `CantidadAntes` tinyint(4) NOT NULL default '0',
  `CantidadDespues` tinyint(4) NOT NULL default '0',
  `Usuario` tinyint(4) NOT NULL default '0',
  `FechaAjuste` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`IdAjusteInventario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_listados`
--

CREATE TABLE IF NOT EXISTS `ges_listados` (
  `IdListado` bigint(20) unsigned NOT NULL auto_increment,
  `NombrePantalla` tinytext NOT NULL,
  `CodigoSQL` text NOT NULL,
  `Eliminado` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`IdListado`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_locales`
--

CREATE TABLE IF NOT EXISTS `ges_locales` (
  `IdLocal` smallint(5) unsigned NOT NULL auto_increment,
  `IdIdioma` smallint(5) unsigned NOT NULL default '0',
  `IdPais` smallint(5) unsigned NOT NULL default '0',
  `AlmacenCentral` tinyint(1) unsigned NOT NULL default '0',
  `NombreComercial` tinytext NOT NULL,
  `Identificacion` tinytext NOT NULL,
  `Password` tinytext NOT NULL,
  `NombreLegal` tinytext NOT NULL,
  `IdFiscal` tinytext NOT NULL,
  `NFiscal` tinytext NOT NULL,
  `DireccionFactura` tinytext NOT NULL,
  `Poblacion` tinytext NOT NULL,
  `CodigoPostal` tinytext NOT NULL,
  `Telefono` tinytext NOT NULL,
  `Fax` tinytext NOT NULL,
  `Movil` tinytext NOT NULL,
  `Email` tinytext NOT NULL,
  `PaginaWeb` tinytext NOT NULL,
  `ImpuestoIncluido` tinyint(1) unsigned NOT NULL default '0',
  `IdTipoNumeracionFactura` smallint(5) unsigned NOT NULL default '0',
  `CuentaBancaria` tinytext NOT NULL,
  `Logotipo` tinytext NOT NULL,
  `MensajeMes` tinytext NOT NULL,
  `SerieDefecto` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdLocal`),
  UNIQUE KEY `IdLocal` (`IdLocal`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_logsql`
--

CREATE TABLE IF NOT EXISTS `ges_logsql` (
  `Idlogsql` int(10) unsigned NOT NULL auto_increment,
  `TipoProceso` tinytext NOT NULL,
  `IdProceso` smallint(5) unsigned NOT NULL default '0',
  `Descripcion` tinytext NOT NULL,
  `Sql` text NOT NULL,
  `CreadoPor` enum('web','agencia','alojamiento','admin') NOT NULL default 'web',
  `IdCreador` smallint(5) unsigned NOT NULL default '0',
  `Exito` tinyint(1) unsigned NOT NULL default '0',
  `FechaCreacion` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`Idlogsql`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2878 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_marcas`
--

CREATE TABLE IF NOT EXISTS `ges_marcas` (
  `IdMarca` smallint(5) unsigned NOT NULL auto_increment,
  `Marca` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdMarca`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_mensajes`
--

CREATE TABLE IF NOT EXISTS `ges_mensajes` (
  `IdMensaje` bigint(20) NOT NULL auto_increment,
  `Titulo` tinytext NOT NULL,
  `Texto` tinytext NOT NULL,
  `IdAutor` bigint(20) NOT NULL default '0',
  `IdOrigenLocal` bigint(20) NOT NULL default '0',
  `IdLocalRestriccion` bigint(20) NOT NULL default '0',
  `IdUsuarioRestriccion` bigint(20) NOT NULL default '0',
  `Status` enum('Normal','Urgente','Privado','Sistema') NOT NULL default 'Normal',
  `Fecha` datetime NOT NULL default '0000-00-00 00:00:00',
  `DiasCaduca` smallint(6) NOT NULL default '1',
  `Eliminado` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`IdMensaje`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_modalidadespago`
--

CREATE TABLE IF NOT EXISTS `ges_modalidadespago` (
  `IdModPago` smallint(5) unsigned NOT NULL auto_increment,
  `ModalidadPago` tinytext NOT NULL,
  PRIMARY KEY  (`IdModPago`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_modistos`
--

CREATE TABLE IF NOT EXISTS `ges_modistos` (
  `IdModisto` smallint(5) unsigned NOT NULL auto_increment,
  `NombreComercial` tinytext NOT NULL,
  `NombreLegal` tinytext NOT NULL,
  `NumeroFiscal` tinytext NOT NULL,
  `Direccion` tinytext NOT NULL,
  `CP` tinytext NOT NULL,
  `Localidad` tinytext NOT NULL,
  `IdPais` smallint(5) unsigned NOT NULL default '0',
  `Descuento` double unsigned NOT NULL default '0',
  `CuentaBancaria` tinytext NOT NULL,
  `IdModPagoHabitual` smallint(5) unsigned NOT NULL default '0',
  `Telefono1` tinytext NOT NULL,
  `Telefono2` tinytext NOT NULL,
  `Email` tinytext NOT NULL,
  `PaginaWeb` tinytext NOT NULL,
  `Contacto` tinytext NOT NULL,
  `Cargo` tinytext NOT NULL,
  `Comentarios` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdModisto`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_paises`
--

CREATE TABLE IF NOT EXISTS `ges_paises` (
  `IdPais` smallint(5) unsigned NOT NULL auto_increment,
  `NombrePais` tinytext NOT NULL,
  `IdIdiomaDefecto` smallint(5) unsigned NOT NULL default '0',
  `IdFiscal` tinytext NOT NULL,
  `TipoImpuestoDefecto` tinytext NOT NULL,
  `ImpuestoDefecto` double NOT NULL default '0',
  `SimboloMoneda` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdPais`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_parametros`
--

CREATE TABLE IF NOT EXISTS `ges_parametros` (
  `Id` smallint(5) unsigned NOT NULL auto_increment,
  `MultiLocal` tinyint(1) unsigned NOT NULL default '0',
  `MultiPais` tinyint(1) unsigned NOT NULL default '0',
  `MultiIdioma` tinyint(1) unsigned NOT NULL default '0',
  `AlmacenCentral` smallint(5) unsigned NOT NULL default '0',
  `VentaOnline` tinyint(1) unsigned NOT NULL default '0',
  `Inventario` tinyint(1) unsigned NOT NULL default '0',
  `Compras` tinyint(1) unsigned NOT NULL default '0',
  `GestionInventarios` enum('FIFO','LIFO','AVERAGE') NOT NULL default 'FIFO',
  `Tallas` tinyint(1) unsigned NOT NULL default '0',
  `Colores` tinyint(1) unsigned NOT NULL default '0',
  `Zapaterias` tinyint(1) unsigned NOT NULL default '0',
  `AltoBarras` tinyint(4) NOT NULL default '10',
  `AnchoBarras` int(4) NOT NULL default '200',
  `MaxCodBarras` tinyint(4) NOT NULL default '8',
  `AlmacenTransito` int(11) NOT NULL default '0',
  `IdFamiliaDefecto` tinyint(4) NOT NULL default '1',
  `IdSubFamiliaDefecto` tinyint(4) NOT NULL default '1',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_pedidos`
--

CREATE TABLE IF NOT EXISTS `ges_pedidos` (
  `IdPedido` int(10) unsigned NOT NULL auto_increment,
  `IdLocal` smallint(6) NOT NULL default '0',
  `IdUsuario` smallint(6) NOT NULL default '0',
  `SeriePedido` tinytext NOT NULL,
  `NPedido` int(10) unsigned NOT NULL default '0',
  `FechaPedido` date NOT NULL default '0000-00-00',
  `IdCliente` tinyint(4) NOT NULL default '0',
  `ImporteNeto` double NOT NULL default '0',
  `IvaImporte` double NOT NULL default '0',
  `TotalImporte` double NOT NULL default '0',
  `ImportePendiente` double NOT NULL default '0',
  `Status` tinyint(1) unsigned NOT NULL default '0',
  `ObraRealizada` tinytext NOT NULL,
  `SerieNumeroPedido` tinytext NOT NULL,
  `NombreComercial` tinytext NOT NULL,
  `Direccion` tinytext NOT NULL,
  `Poblacion` tinytext NOT NULL,
  `CIF` tinytext NOT NULL,
  `CodigoPostal` tinytext NOT NULL,
  `Observaciones` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdPedido`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_pedidos_det`
--

CREATE TABLE IF NOT EXISTS `ges_pedidos_det` (
  `IdPedidoDet` int(10) unsigned NOT NULL auto_increment,
  `IdPedido` int(10) unsigned NOT NULL default '0',
  `IdProducto` smallint(5) unsigned NOT NULL default '0',
  `Referencia` tinytext NOT NULL,
  `CodigoBarras` tinytext NOT NULL,
  `Concepto` tinytext NOT NULL,
  `Talla` tinytext NOT NULL,
  `Color` tinytext NOT NULL,
  `Cantidad` int(10) unsigned NOT NULL default '0',
  `Precio` double NOT NULL default '0',
  `Descuento` double NOT NULL default '0',
  `Importe` double NOT NULL default '0',
  `Iva` double NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdPedidoDet`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_perfiles`
--

CREATE TABLE IF NOT EXISTS `ges_perfiles` (
  `IdPerfil` smallint(5) unsigned NOT NULL auto_increment,
  `NombrePerfil` tinytext NOT NULL,
  `Administracion` tinyint(1) unsigned NOT NULL default '0',
  `InformeLocal` tinyint(1) unsigned NOT NULL default '0',
  `Informes` tinyint(1) unsigned NOT NULL default '0',
  `Productos` tinyint(1) unsigned NOT NULL default '0',
  `Proveedores` tinyint(1) unsigned NOT NULL default '0',
  `Compras` tinyint(1) unsigned NOT NULL default '0',
  `Stocks` tinyint(1) unsigned NOT NULL default '0',
  `VerStocks` tinyint(1) unsigned NOT NULL default '0',
  `Clientes` tinyint(1) unsigned NOT NULL default '0',
  `TPV` tinyint(1) unsigned NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdPerfil`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_presupuestos`
--

CREATE TABLE IF NOT EXISTS `ges_presupuestos` (
  `IdPresupuesto` int(10) unsigned NOT NULL auto_increment,
  `IdLocal` smallint(6) NOT NULL default '0',
  `IdUsuario` smallint(6) NOT NULL default '0',
  `SeriePresupuesto` tinytext NOT NULL,
  `NPresupuesto` int(10) unsigned NOT NULL default '0',
  `FechaPresupuesto` date NOT NULL default '0000-00-00',
  `IdCliente` tinyint(4) NOT NULL default '0',
  `ImporteNeto` double NOT NULL default '0',
  `IvaImporte` double NOT NULL default '0',
  `TotalImporte` double NOT NULL default '0',
  `ImportePendiente` double NOT NULL default '0',
  `Status` tinyint(1) unsigned NOT NULL default '0',
  `ObraRealizada` tinytext NOT NULL,
  `SerieNumeroPresupuesto` tinytext NOT NULL,
  `NombreComercial` tinytext NOT NULL,
  `Direccion` tinytext NOT NULL,
  `Poblacion` tinytext NOT NULL,
  `CIF` tinytext NOT NULL,
  `CodigoPostal` tinytext NOT NULL,
  `Observaciones` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdPresupuesto`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_presupuestos_det`
--

CREATE TABLE IF NOT EXISTS `ges_presupuestos_det` (
  `IdPresupuestoDet` int(10) unsigned NOT NULL auto_increment,
  `IdPresupuesto` int(10) unsigned NOT NULL default '0',
  `IdProducto` smallint(5) unsigned NOT NULL default '0',
  `Referencia` tinytext NOT NULL,
  `CodigoBarras` tinytext NOT NULL,
  `Concepto` tinytext NOT NULL,
  `Talla` tinytext NOT NULL,
  `Color` tinytext NOT NULL,
  `Cantidad` int(10) unsigned NOT NULL default '0',
  `Precio` double NOT NULL default '0',
  `Descuento` double NOT NULL default '0',
  `Importe` double NOT NULL default '0',
  `Iva` double NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdPresupuestoDet`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_productos`
--

CREATE TABLE IF NOT EXISTS `ges_productos` (
  `IdProducto` smallint(5) unsigned NOT NULL auto_increment,
  `IdMarca` smallint(5) unsigned NOT NULL default '0',
  `IdProdBase` smallint(5) unsigned NOT NULL default '0',
  `Referencia` tinytext NOT NULL,
  `CodigoBarras` tinytext NOT NULL,
  `CosteSinIVA` double NOT NULL default '0',
  `PrecioVenta` float NOT NULL,
  `Impuesto` double NOT NULL default '0',
  `StockIlimitado` tinyint(1) unsigned NOT NULL default '0',
  `RefProvHab` tinytext NOT NULL,
  `IdProvHab` smallint(5) unsigned NOT NULL default '0',
  `IdTallaje` smallint(5) unsigned NOT NULL default '0',
  `IdTalla` smallint(5) unsigned NOT NULL default '0',
  `IdNumeroZapato` smallint(5) unsigned NOT NULL default '0',
  `IdColor` smallint(5) unsigned NOT NULL default '0',
  `IdFamilia` smallint(5) unsigned NOT NULL default '0',
  `IdSubFamilia` smallint(5) unsigned NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdProducto`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_productos_idioma`
--

CREATE TABLE IF NOT EXISTS `ges_productos_idioma` (
  `IdProdIdioma` smallint(5) unsigned NOT NULL auto_increment,
  `IdProdBase` smallint(5) unsigned NOT NULL default '0',
  `IdIdioma` smallint(5) unsigned NOT NULL default '0',
  `Nombre` tinytext NOT NULL,
  `Descripcion` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdProdIdioma`),
  KEY `IdProducto` (`IdProdBase`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_proveedores`
--

CREATE TABLE IF NOT EXISTS `ges_proveedores` (
  `IdProveedor` smallint(5) unsigned NOT NULL auto_increment,
  `NombreComercial` tinytext NOT NULL,
  `NombreLegal` tinytext NOT NULL,
  `NumeroFiscal` tinytext NOT NULL,
  `Direccion` tinytext NOT NULL,
  `CP` tinytext NOT NULL,
  `Localidad` tinytext NOT NULL,
  `IdPais` smallint(5) unsigned NOT NULL default '0',
  `Descuento` double unsigned NOT NULL default '0',
  `CuentaBancaria` tinytext NOT NULL,
  `IdModPagoHabitual` smallint(5) unsigned NOT NULL default '0',
  `Telefono1` tinytext NOT NULL,
  `Telefono2` tinytext NOT NULL,
  `Email` tinytext NOT NULL,
  `PaginaWeb` tinytext NOT NULL,
  `Contacto` tinytext NOT NULL,
  `Cargo` tinytext NOT NULL,
  `Comentarios` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdProveedor`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_status_compras`
--

CREATE TABLE IF NOT EXISTS `ges_status_compras` (
  `Id` smallint(5) unsigned NOT NULL auto_increment,
  `IdStatus` tinyint(3) unsigned NOT NULL default '0',
  `Status` tinytext NOT NULL,
  PRIMARY KEY  (`Id`),
  KEY `IdStatus` (`IdStatus`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_status_facturas`
--

CREATE TABLE IF NOT EXISTS `ges_status_facturas` (
  `Id` smallint(5) unsigned NOT NULL auto_increment,
  `IdStatus` tinyint(3) unsigned NOT NULL default '0',
  `Status` tinytext NOT NULL,
  PRIMARY KEY  (`Id`),
  KEY `IdStatus` (`IdStatus`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_subfamilias`
--

CREATE TABLE IF NOT EXISTS `ges_subfamilias` (
  `Id` smallint(5) unsigned NOT NULL auto_increment,
  `IdFamilia` smallint(5) unsigned NOT NULL default '0',
  `IdSubFamilia` smallint(5) unsigned NOT NULL default '0',
  `IdIdioma` smallint(5) unsigned NOT NULL default '0',
  `SubFamilia` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`Id`),
  KEY `IdFamilia` (`IdFamilia`,`IdSubFamilia`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=153 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_tallajes`
--

CREATE TABLE IF NOT EXISTS `ges_tallajes` (
  `IdTallaje` tinyint(3) unsigned NOT NULL auto_increment,
  `Tallaje` tinytext NOT NULL,
  PRIMARY KEY  (`IdTallaje`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_tallas`
--

CREATE TABLE IF NOT EXISTS `ges_tallas` (
  `Id` smallint(5) unsigned NOT NULL auto_increment,
  `IdTallaje` tinyint(3) unsigned NOT NULL default '0',
  `IdTalla` smallint(5) unsigned NOT NULL default '0',
  `SizeOrden` tinyint(3) unsigned NOT NULL default '0',
  `IdIdioma` smallint(5) unsigned NOT NULL default '0',
  `Talla` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`Id`),
  KEY `IdTalla` (`IdTalla`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_templates`
--

CREATE TABLE IF NOT EXISTS `ges_templates` (
  `IdTemplate` smallint(5) unsigned NOT NULL auto_increment,
  `Codigo` text NOT NULL,
  `Nombre` tinytext NOT NULL,
  `Comentario` tinytext NOT NULL,
  `Paginas` tinyint(4) NOT NULL default '0',
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdTemplate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ges_usuarios`
--

CREATE TABLE IF NOT EXISTS `ges_usuarios` (
  `IdUsuario` smallint(5) unsigned NOT NULL auto_increment,
  `Nombre` tinytext NOT NULL,
  `Identificacion` tinytext NOT NULL,
  `Password` tinytext NOT NULL,
  `IdIdioma` smallint(5) unsigned NOT NULL default '0',
  `Direccion` tinytext NOT NULL,
  `Telefono` tinytext NOT NULL,
  `Foto` tinytext NOT NULL,
  `FechaNacim` date NOT NULL default '0000-00-00',
  `Comision` double NOT NULL default '0',
  `IdPerfil` smallint(5) unsigned NOT NULL default '0',
  `AdministradorWeb` tinyint(1) unsigned NOT NULL default '0',
  `CuentaBanco` tinytext NOT NULL,
  `Eliminado` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`IdUsuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;
